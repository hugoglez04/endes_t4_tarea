package org.example;

import java.util.ArrayList;
/**
 * Clase que representa un concesionario de autos.
 * Permite agregar autos, listarlos y imprimirlos.
 */
public class Concesionario {

    // Lista de autos en el concesionario
    private ArrayList<Auto> autos;

    /**
     * Constructor de la clase Concesionario.
     * Inicializa la lista de autos.
     */
    public Concesionario() {
        autos = new ArrayList<>();
    }

    /**
     * Método para agregar un auto al concesionario.
     * @param auto El auto a agregar.
     */
    public void agregarAuto(Auto auto) {
        autos.add(auto);
    }

    /**
     * Método para obtener la lista de autos del concesionario.
     * @return La lista de autos.
     */
    public ArrayList<Auto> listarAutos() {
        return autos;
    }

    /**
     * Método para imprimir los autos del concesionario.
     */
    public void imprimirAutos(){
        for (Auto auto: autos){
            System.out.println(auto);
        }
    }
}
