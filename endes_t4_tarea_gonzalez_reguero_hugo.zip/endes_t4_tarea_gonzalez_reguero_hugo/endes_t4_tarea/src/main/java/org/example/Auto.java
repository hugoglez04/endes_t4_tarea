package org.example;

import java.util.ArrayList;

/**
 * Clase que representa un auto con una marca y un modelo.
 */
public class Auto {

    // Marca del auto
    private String marca;

    // Modelo del auto
    private String modelo;

    /**
     * Constructor de la clase Auto.
     * @param marca La marca del auto.
     * @param modelo El modelo del auto.
     */
    public Auto(String marca, String modelo) {
        this.marca = marca;
        this.modelo = modelo;
    }

    /**
     * Método para obtener la marca del auto.
     * @return La marca del auto.
     */
    public String getMarca() {
        return marca;
    }

    /**
     * Método para establecer la marca del auto.
     * @param marca La nueva marca del auto.
     */
    public void setMarca(String marca) {
        this.marca = marca;
    }

    /**
     * Método para obtener el modelo del auto.
     * @return El modelo del auto.
     */
    public String getModelo() {
        return modelo;
    }

    /**
     * Método para establecer el modelo del auto.
     * @param modelo El nuevo modelo del auto.
     */
    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    /**
     * Método para representar el auto como una cadena de texto.
     * @return Una representación en formato de cadena del auto.
     */
    @Override
    public String toString() {
        return "Auto [marca=" + marca + ", modelo=" + modelo + "]";
    }
}

